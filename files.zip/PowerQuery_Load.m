// Power BI > Get Data > Excel > select IT_Expenditure_StarSchema.xlsx > tick all 6 sheets > Load.
// Then apply these checks in Transform Data (optional, data is already cleaned):
// Fact_IT: set Actual/Forecast/Plan/Outlook = Fixed decimal number; keys = Whole number; Source = Text.
// Dim_Date: IsClosed = True/False. Sort Month by MonthNo (Column tools > Sort by column).
// ---- If you prefer loading the ORIGINAL file and cleaning in Power Query, use this: ----
let
    Source   = Excel.Workbook(File.Contents("C:\Path\IT_Expenditure_dataset.xlsx"), null, true),
    DataT    = Source{[Item="Data",Kind="Sheet"]}[Data],
    Promoted = Table.PromoteHeaders(DataT, [PromoteAllScalars=true]),
    Renamed  = Table.RenameColumns(Promoted,{{"Date","Month"},{"Cost element name","Cost Element"}}),
    Typed    = Table.TransformColumnTypes(Renamed,{{"Actual",type number},{"Forecast",type number},{"Plan",type number}}),
    NoNulls  = Table.ReplaceValue(Typed,null,0,Replacer.ReplaceValue,{"Actual","Forecast","Plan"}),
    MonthNo  = Table.AddColumn(NoNulls,"MonthNo", each List.PositionOf({"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"},[Month])+1, Int64.Type),
    Trimmed  = Table.TransformColumns(MonthNo,{{"Region",Text.Trim},{"Country",Text.Trim},{"Business Area",Text.Trim}})
in
    Trimmed
