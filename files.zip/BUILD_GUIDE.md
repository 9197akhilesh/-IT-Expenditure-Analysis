# IT Expenditure Analysis – Power BI Build Guide (≈45 min in Power BI Desktop)

## 1. Load (5 min)
1. Home > Get data > Excel > `IT_Expenditure_StarSchema.xlsx` > tick all 6 sheets > Load.
2. Home > Themes > Browse for themes > `IT_Dashboard_Theme.json`.
3. Dim_Date: select `Month` > Column tools > Sort by column > `MonthNo`.
4. Create table `_Measures` (Enter data, blank) and paste everything from `DAX_Measures.dax`.
5. Enter data > table `Metric Selector`, column `Metric` = Actual / Forecast / Plan.

## 2. Data model (Model view) – star schema, all Many-to-One, single direction
| From (Fact_IT) | To | Key |
|---|---|---|
| MonthNo | Dim_Date | MonthNo |
| GeoKey | Dim_Geography | GeoKey |
| BusinessKey | Dim_Business | BusinessKey |
| ITKey | Dim_ITArea | ITKey |
| CostKey | Dim_Cost | CostKey |

Hide all key columns in Report view. Format money measures `$#,0.0,,"M"`, % measures `0.0%`.
Hierarchies: Geography (Region > Country), IT (IT_Area > IT_Sub_Area), Cost (Group > Sub Group > Element).

## 3. Data preparation decisions (for demo section 3)
| Issue found | Treatment |
|---|---|
| Actual/Forecast/Plan blank in ~72% / 61% / 67% of rows (each row carries one measure) | Blanks → 0, rows aggregated to one fact grain |
| Actual exists only Jan–Aug; forecast = actual for closed months | `IsClosed` flag; YTD variance compares Actual vs Plan only on closed months |
| "Future Data" sheet (Sep–Dec) has a column named *Actual* | Renamed **Outlook** to avoid mixing with true actuals |
| 1,929 duplicate rows, 23 cost sub-groups, 38 IT sub-areas | Normalised into 5 dimensions |
| Date is month text | Replaced with `MonthNo` + Dim_Date (sorted properly) |
| Africa & Asia has **zero plan** | Status measure returns "No Plan" instead of a false % |

## 4. Report pages (16:9, dark navy theme)
**Page 1 – Executive Summary**
- Top: slicers (Region, Business_Area, Quarter) as tiles/dropdowns.
- Cards: Plan | Forecast | Actual (YTD) | Forecast vs Plan % (conditional colour using `Status Color`) | Budget Utilisation %.
- Headline text box bound to `Headline`.
- Line + clustered column: Month × Actual / Forecast / Plan.
- Donut: Forecast by Cost_Element_Group. Treemap: Forecast by IT_Area > IT_Sub_Area.

**Page 2 – Variance Analysis**
- Clustered bar: Forecast vs Plan % by Region (conditional format with `Status Color`).
- Matrix: Business_Area × Cost_Element_Group, values = Forecast vs Plan %, background colour scale (red–amber–teal).
- Waterfall: Plan → Forecast variance by IT_Area.
- Top-N filter using `Deviation Rank (Region)` ≤ 5.

**Page 3 – Cost Drivers**
- Stacked column: Labor sub-groups (Internal vs External) by month.
- Clustered column: Shared Services Forecast vs Plan by Region.
- Treemap: Cost_Element_Sub_Group. Table: top 10 Cost_Element by variance.

**Page 4 – Trend & Outlook**
- Area chart: Cumulative Forecast vs Cumulative Plan.
- Column: Outlook (Sep–Dec) vs Forecast. Line: Forecast MoM %.
- Metric Selector slicer driving a column chart with `Selected Metric` + `Title - Variance`.

Extras for polish: bookmarks + buttons for page navigation, drill-through page from Region > Country, tooltips pages showing sub-group detail, Sync slicers across pages.

## 5. Insights verified in the data (use in demo section 5)
- Full-year forecast ≈ **$890.5M vs plan $900.4M (-1.1%)**; Actuals Jan–Aug ≈ $555.7M.
- Jan was heavily under plan ($58.5M actual vs $86.7M plan); Jul–Aug forecast ran **above** plan (Jul +$4.3M, Aug +$9.9M).
- **Europe – "Other" costs: forecast +107% vs plan** → biggest overspend hotspot; investigate travel/misc.
- **USA Shared Services: forecast -65% vs plan** and **Aus & NZ Depreciation: -90%** → budget possibly mis-allocated; candidates for rebudgeting.
- **Enablement** is the most underutilised IT Area (-9.7% vs plan); BU Support is +1.9% over.
- **Labor is ~53% of forecast**; USA Labor +2.3% over plan.
- **Africa & Asia has no plan at all** while forecasting ~$3.1M → governance gap.
- December outlook spikes to ≈ $94.6M vs ≈ $70–73M for Sep–Nov → check year-end accruals.

## 6. Demo script (7 sections → pages)
1. Problem: "How do we monitor and optimise IT spend vs plan?" – Page 1 headline.
2. Data: dataset size (81.6K + 12.1K rows), cleaning table above, Model view.
3. EDA: Page 1 trend, treemap concentration (USA ≈ 85% of spend).
4. Methods: show 3 variance measures + Status logic (±5% thresholds).
5. Insights: Page 2 matrix → Europe Other, USA Shared Services.
6. Story: Page 1 → 2 → 3 → 4 flow, finish with recommendations.
7. Workflow quality: star schema, `_Measures` table, no calculated columns where measures work.

## 7. Recommendations to close with
1. Re-plan Africa & Asia and USA Shared Services.
2. Review Europe "Other" spend approvals.
3. Reallocate unused Enablement / Depreciation budget.
4. Validate December accruals before year-end.
